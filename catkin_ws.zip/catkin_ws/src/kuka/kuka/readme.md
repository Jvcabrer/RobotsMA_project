# kuka

## Overview

This package is part of the [ROS-Industrial][] program. See the main [KUKA][] page on the ROS wiki for more information on usage.


[ROS-Industrial]: http://wiki.ros.org/Industrial
[KUKA]: http://wiki.ros.org/kuka
